/* globals DashTimer, d3*/
function createDash(selector, colors, total, endPoint) {

    var dt = new DashTimer(selector).init({
        height: 150,
        width: 150,
        start: {
            innerRatio: 1,
            outerRatio: .9,         
            fill: colors.start
        },
        finish: {
            innerRatio: 1,
            outerRatio: .9,            
            fill: colors.start
        }
    }).setData([{
        immediate: {
            angle: true
        },
        start: {
            angle: 1,
            fill: colors.end
        },
        finish: {
            angle: 0,
            fill: colors.end
        }
    }, {
        values: {
            show: true,
            decorate: function(d) {
                return total;
            }
        }
    }]).start(1000, 0, endPoint);
}
module.exports = {
    createDash: createDash
}