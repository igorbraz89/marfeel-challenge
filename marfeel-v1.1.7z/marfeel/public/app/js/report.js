document.addEventListener("DOMContentLoaded", function(event) {
    const Dash = require("./components/dash");
    const numberFormat = require('numeral')
    
    const revenue = getResources("/revenue", '#revenue', {start: "#3f691a", end: "#8ad441"});
    const impressions = getResources("/impressions", "#impressions", {start: "#285267", end: "#6ac9e8"});
    const visits = getResources("/visits", "#visits", {start: "#bb591e", end: "#eac53c"});

    console.log(revenue, impressions, visits);

    //Dash.createDash("#impressions", {start: "#3f691a", end: "#8ad441"}, "600", .25);
    //Dash.createDash("#visits", {start: "#3f691a", end: "#8ad441"}, 5000, .25);

    async function retrieveDash(data, selector, colors) {
        let currencyCode,
            total = 0;
        data.forEach(element => {
            total +=  parseFloat(element.total) ;
            if(element.currency) {
                currencyCode = element.currency;
            }
        });
        total = numberFormat(total).format('0,00.00');
        total.replace(",", ".");
        //await Dash.createDash(selector, {start: "#3f691a", end: "#8ad441"}, total, .25);
        await Dash.createDash(selector, {start: colors.start, end: colors.end}, total, .25);
    }

    function getResources(path, selector, colors) {
        fetch(path).then((result) => {
            return result.json();
        }) .then(function(data) {
            //console.log(data)
            retrieveDash(data, selector, colors)
        });
    }
});